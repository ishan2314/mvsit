# Spring-Boot-WebSocket
Building a chat application using Spring Boot and Web Socket
